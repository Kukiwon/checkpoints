module.exports = function(CheckPoint) {

};
